package com.example.quanlychitieu;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity {
    Button btnLogin;
    EditText username;
    ArrayList<String> myData;
    SQLiteDatabase myDatabase;
    EditText pass;
    TextView signIn;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        username = (EditText)findViewById(R.id.username);
        pass = (EditText)findViewById(R.id.pass);
        btnLogin = (Button)findViewById(R.id.btn_login);
        signIn = (TextView)findViewById(R.id.signIn);
        //Tạo adapter và list
        myData = new ArrayList<>();
        //Tạo (nếu chưa có) hoặc là mở CSDL
        myDatabase = openOrCreateDatabase("QuanLyChiTieu.db",MODE_PRIVATE, null);


        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = username.getText().toString().trim();
                String mk = pass.getText().toString().trim();
                //Lọc qua CSDL để tìm tài khoản
                try {
                    String sql = "SELECT * FROM TaiKhoan";
                    myDatabase.execSQL(sql);
                }
                catch (Exception e){
                    Toast.makeText(LoginActivity.this, "Thông tin đăng nhập chưa có vui lòng Đăng Ký trước", Toast.LENGTH_LONG).show();

                }

                myData.clear(); //làm mới lại vùng chứa myData
                String sql = "SELECT * FROM TaiKhoan";
                Cursor c = myDatabase.rawQuery(sql, null);
                c.moveToFirst();
                String data = "";
                while (!c.isAfterLast()){
                    if (user.equals(c.getString(1).trim())  && mk.equals(c.getString(2).trim())){
                        //Đưa một giá trị vào myData nếu người dùng đã có tài khoản và nhập đúng
                        data = c.getString(1).trim();
                        myData.add(data);
                        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                        startActivity(intent);

                    }
                    c.moveToNext();
                }
                c.close();


                //Kiểm tra myData có chứa giá trị nào không nếu không nghĩa là người dùng nhập sai thông tin
                if(myData == null) {
                    Toast.makeText(LoginActivity.this, "Sai thông tin đăng nhập hoặc chưa ĐĂNG KÝ", Toast.LENGTH_LONG).show();
                }
            }
        });
        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*Dialog register = new Dialog(LoginActivity.this);
                register.setTitle("Đăng ký tài khoản");
                register.setCancelable(false);
                register.setContentView(R.layout.register);*/

                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);


            }
        });

    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder myDialog = new AlertDialog.Builder(LoginActivity.this);
        myDialog.setTitle("Quản lý chi tiêu");
        myDialog.setMessage("Bạn có muốn thoát ứng dụng không?");
        myDialog.setIcon(R.drawable.app_logo);
        myDialog.setPositiveButton("Thoát", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
            }
        });

        myDialog.setNegativeButton("Không", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        myDialog.create().show();

    }
}
