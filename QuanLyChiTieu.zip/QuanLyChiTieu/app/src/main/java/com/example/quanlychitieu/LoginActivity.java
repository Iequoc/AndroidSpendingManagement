package com.example.quanlychitieu;

import android.app.Dialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity {
    Button btnLogin;
    EditText username;
    ArrayList<String> myData;
    SQLiteDatabase myDatabase;
    EditText pass;
    TextView signIn;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        username = (EditText)findViewById(R.id.username);
        pass = (EditText)findViewById(R.id.pass);
        btnLogin = (Button)findViewById(R.id.btn_login);
        signIn = (TextView)findViewById(R.id.signIn);
        //Tạo adapter và list
        myData = new ArrayList<>();
        //Tạo (nếu chưa có) hoặc là mở CSDL
        myDatabase = openOrCreateDatabase("QuanLyChiTieu.db",MODE_PRIVATE, null);
        try {
            // Tạo ra một bảng để chứa thông tin người dùng gồm mật khẩu và tên đăng nhập

            String sql = "CREATE TABLE TaiKhoan(ID INTEGER PRIMARY KEY AUTOINCREMENT, USERNAME TEXT UNIQUE, PASSWORD TEXT )";
            myDatabase.execSQL(sql);
            // Tạo tài khoản mặc định cho người dùng với tên đăng nhập "admin" và mật khẩu "admin"
            String ttk = "admin";
            String mk = "admin";
            ContentValues myValues = new ContentValues();
            myValues.put("USERNAME", ttk);
            myValues.put("PASSWORD", mk);
            myDatabase.insert("TaiKhoan",null, myValues);
        }
        catch (Exception e){
            Log.e("Error", "Không thể thêm tài khoản mặc định");
        }

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = username.getText().toString().trim();
                String mk = pass.getText().toString().trim();
                //Lọc qua CSDL để tìm tài khoản

                try {
                    String sql1 = "SELECT * FROM TaiKhoan";
                    myDatabase.rawQuery(sql1, null);
                }
                catch (Exception e){
                    Toast.makeText(LoginActivity.this, "Thông tin đăng nhập chưa có vui lòng Đăng Ký trước", Toast.LENGTH_LONG).show();

                }

                myData.clear(); //làm mới lại vùng chứa myData
                String sql = "SELECT * FROM TaiKhoan";
                Cursor c = myDatabase.rawQuery(sql, null);
                c.moveToFirst();
                String tb = "";
                while (!c.isAfterLast()){
                    if (user.equals(c.getString(1).trim())  && mk.equals(c.getString(2).trim())){
                        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                        startActivity(intent);
                        finish();
                        tb = "Đăng nhập THÀNH CÔNG";
                        break;
                    }
                    else {
                        c.moveToNext();
                        tb = "Sai thông tin hoặc chưa ĐĂNG KÝ";
                    }

                }

                c.close();


                //Hiển thị thông báo
                Toast.makeText(LoginActivity.this, tb, Toast.LENGTH_LONG).show();

            }
        });
        //Chuyển sang đăng ký
        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*Dialog register = new Dialog(LoginActivity.this);
                register.setTitle("Đăng ký tài khoản");
                register.setCancelable(false);
                register.setContentView(R.layout.register);*/

                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
                finish();


            }
        });

    }

    @Override

    public void onBackPressed() {
        AlertDialog.Builder myDialog = new AlertDialog.Builder(LoginActivity.this);
        myDialog.setTitle("Quản lý chi tiêu");
        myDialog.setMessage("Bạn có muốn thoát ứng dụng không?");
        myDialog.setIcon(R.drawable.app_logo);
        myDialog.setPositiveButton("Thoát", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
            }
        });

        myDialog.setNegativeButton("Không", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        myDialog.show();

    }
}
