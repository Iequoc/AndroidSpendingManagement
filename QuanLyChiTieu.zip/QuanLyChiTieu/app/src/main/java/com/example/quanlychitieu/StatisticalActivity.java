package com.example.quanlychitieu;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.quanlychitieu.R;

import java.util.ArrayList;

public class  StatisticalActivity extends AppCompatActivity {
    Button btn_out;
    Button btn_addExpenses;
    TextView totalExpenses, totalRevenue, total1;

    Button btn_expenses;
    Button btn_statistical;
    Button btn_revenue;

    ListView containerDataExpenses;
    ListView containerDataRevenue;
    ArrayList<String> myData;
    ArrayList<String> myData1;
    ArrayAdapter<String> myAdapter;
    ArrayAdapter<String> myAdapter1;
    SQLiteDatabase myDatabase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.statistical);
        totalExpenses = (TextView)findViewById(R.id.totalExpenses);
        totalRevenue = (TextView)findViewById(R.id.totalRevenue);
        total1 = (TextView)findViewById(R.id.total);


        //Chuyển sang trang khoản chi
        btn_expenses = (Button)findViewById(R.id.btn_expenses);
        btn_expenses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(StatisticalActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
        //Chuyển sang trang khoản thu
        btn_revenue = (Button)findViewById(R.id.btn_revenue);
        btn_revenue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(StatisticalActivity.this, Revenue.class);
                startActivity(intent);
            }
        });


        //Tạo ListView
        containerDataExpenses = findViewById(R.id.containerDataExpenses);
        containerDataRevenue = findViewById(R.id.containerDataRevenue);
        myData = new ArrayList<>();
        myData1 = new ArrayList<>();
        myAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, myData);
        myAdapter1 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, myData1);
        containerDataExpenses.setAdapter(myAdapter);
        containerDataRevenue.setAdapter(myAdapter1);
        //Tạo CSDL
        myDatabase = openOrCreateDatabase("QuanLyChiTieu.db",MODE_PRIVATE, null);
        //Tạo table chứa dữ liệu
        try {
            String sql = "CREATE TABLE TB_THU(ID INTEGER PRIMARY KEY AUTOINCREMENT, TEN_KT TEXT, TIEN INTEGER )";
            myDatabase.execSQL(sql);
        }
        catch (Exception e)
        {
            Log.e("Error", "Bảng đã tồn tại");
        }


        btn_out = (Button)findViewById(R.id.btn_out);


        //Thoát app
        btn_out.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(StatisticalActivity.this, LoginActivity.class);
                startActivity(intent);

            }
        });

        LoadData();
        LoadDataRevenue();


    }
    //Load dữ liệu lên 2 bảng thống kê
    private void LoadDataRevenue(){
        int total = 0;
        myData1.clear();
        String sql = "SELECT * FROM TB_THU";
        Cursor c = myDatabase.rawQuery(sql, null);
        c.moveToFirst();
        String data = "";
        while (!c.isAfterLast()){
            total+= Integer.parseInt(c.getString(2));
            data = c.getString(0) + " | " + c.getString(1) + " | " + c.getString(2);
            myData1.add(data);
            c.moveToNext();
            totalRevenue.setText("Tổng thu: "+ total);


        }

        c.close();

        myAdapter1.notifyDataSetChanged();

    }
    private void LoadData(){
        int total = 0;
        int totalThu = 0;
        myAdapter.clear();
        String sql = "SELECT * FROM TB_CHI";
        Cursor c = myDatabase.rawQuery(sql, null);
        c.moveToFirst();
        String data = "";
        while (!c.isAfterLast()){
            total+= Integer.parseInt(c.getString(2));
            data = c.getString(0) + " | " + c.getString(1) + " | " + c.getString(2);
            myData.add(data);
            c.moveToNext();
            totalExpenses.setText("Tổng chi: "+ total);
            total1.setText("Tổng thu và chi là: "+ total);


        }
        c.close();

        String sql1 = "SELECT * FROM TB_THU";

        Cursor c1 = myDatabase.rawQuery(sql1, null);
        c1.moveToFirst();
        while (!c1.isAfterLast()){
            totalThu+= Integer.parseInt(c1.getString(2));
            c1.moveToNext();
        }
        c1.close();
        total1.setText("Tổng thu và chi là: "+ (totalThu - total));
        myAdapter.notifyDataSetChanged();

    }


}
