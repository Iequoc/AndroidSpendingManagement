package com.example.quanlychitieu;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.quanlychitieu.R;

import java.util.ArrayList;

public class  StatisticalActivity extends AppCompatActivity {
    Button btn_out;
    Button btn_addExpenses;
    Button btn_expenses;
    Button btn_statistical;
    Button btn_revenue;

    ListView containerDataExpenses;
    ListView containerDataRevenue;
    ArrayList<String> myData;
    ArrayAdapter<String> myAdapter;
    SQLiteDatabase myDatabase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.statistical);
        // Hiển thị những khoản thu đã có sẵn trong database nếu có

        //Chuyển sang trang khoản chi
        btn_expenses = (Button)findViewById(R.id.btn_expenses);
        btn_expenses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(StatisticalActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
        //Chuyển sang trang khoản thu
        btn_revenue = (Button)findViewById(R.id.btn_revenue);
        btn_revenue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(StatisticalActivity.this, Revenue.class);
                startActivity(intent);
            }
        });


        //Tạo ListView
        containerDataExpenses = findViewById(R.id.containerDataExpenses);
        containerDataRevenue = findViewById(R.id.containerDataRevenue);
        myData = new ArrayList<>();
        myAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, myData);
        containerDataRevenue.setAdapter(myAdapter);
        containerDataExpenses.setAdapter(myAdapter);
        //Tạo CSDL
        myDatabase = openOrCreateDatabase("QuanLyChiTieu.db",MODE_PRIVATE, null);
        //Tạo table chứa dữ liệu
        try {
            String sql = "CREATE TABLE TB_THU(ID INTEGER PRIMARY KEY AUTOINCREMENT, TEN_KT TEXT, TIEN INTEGER )";
            myDatabase.execSQL(sql);
        }
        catch (Exception e)
        {
            Log.e("Error", "Bảng đã tồn tại");
        }


        btn_out = (Button)findViewById(R.id.btn_out);


        //Thoát app
        btn_out.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog exit = new Dialog(com.example.quanlychitieu.StatisticalActivity.this);
                exit.setContentView(R.layout.exit);
                Button btn_yes = (Button)exit.findViewById(R.id.btn_yes);
                Button btn_no = (Button)exit.findViewById(R.id.btn_no);
                btn_yes.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        onBackPressed();

                    }
                });
                btn_no.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        exit.cancel();

                    }
                });
                exit.show();
            }
        });

        LoadDataRevenue();
        LoadData();


    }
    private void LoadDataRevenue(){
        myData.clear();
        String sql = "SELECT * FROM TB_THU";
        Cursor c = myDatabase.rawQuery(sql, null);
        c.moveToFirst();
        String data = "";
        while (!c.isAfterLast()){
            data = c.getString(0) + " | " + c.getString(1) + " | " + c.getString(2);
            myData.add(data);
            c.moveToNext();
        }
        c.close();
        myAdapter.notifyDataSetChanged();

    }
    private void LoadData(){
        myData.clear();
        String sql = "SELECT * FROM TB_CHI";
        Cursor c = myDatabase.rawQuery(sql, null);
        c.moveToFirst();
        String data = "";
        while (!c.isAfterLast()){
            data = c.getString(0) + " | " + c.getString(1) + " | " + c.getString(2);
            myData.add(data);
            c.moveToNext();
        }
        c.close();
        myAdapter.notifyDataSetChanged();

    }

}
