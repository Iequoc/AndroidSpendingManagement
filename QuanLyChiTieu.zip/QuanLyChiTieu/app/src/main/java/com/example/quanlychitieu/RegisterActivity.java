package com.example.quanlychitieu;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class RegisterActivity extends AppCompatActivity {
    ArrayList<String> myData;
    ArrayAdapter<String> myAdapter;
    SQLiteDatabase myDatabase;
    EditText us, password;
    Button btn_cancel;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);
        //Tạo adapter và list
        myData = new ArrayList<>();
        myAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, myData);
        //Tạo (nếu chưa có) hoặc là mở CSDL
        myDatabase = openOrCreateDatabase("QuanLyChiTieu.db",MODE_PRIVATE, null);
        //Tạo table chứa dữ liệu
        try {

            Log.e("Error", "Đúnggggg");
        }
        catch (Exception e){
            Log.e("Error", "Saiiiiii");
        }
        try {
            String sql = "CREATE TABLE TaiKhoan(ID INTEGER PRIMARY KEY AUTOINCREMENT, USERNAME TEXT UNIQUE, PASSWORD TEXT )";
            myDatabase.execSQL(sql);

        }
        catch (Exception e)
        {
            Log.e("Error", "Bảng đã tồn tại");
        }


        Button btn_register;
        btn_cancel = (Button)findViewById(R.id.btn_cancel);
        btn_register = (Button)findViewById(R.id.btn_register);
        EditText confirm_pass;
        confirm_pass = (EditText)findViewById(R.id.confirm_pass);
        password = (EditText)findViewById(R.id.password) ;
        us = (EditText)findViewById(R.id.us);
        //Hủy đăng ký
        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();

            }
        });

        btn_register.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                String mk, xnmk, ttk;
                ttk = us.getText().toString();
                mk = password.getText().toString();
                xnmk = confirm_pass.getText().toString();
                if (mk.equals(xnmk)){
                    //Thực hiện lưu vào CSDL
                    ContentValues myValues = new ContentValues();
                    myValues.put("USERNAME", ttk);
                    myValues.put("PASSWORD", mk);
                    String msg ="";
                        if (myDatabase.insert("TaiKhoan",null, myValues) == -1){
                            msg = "Thêm khoản thu THẤT BẠI!!!";
                        }
                        else {
                            msg = "THÀNH CÔNG Thêm khoản thu";
                        }

                    //Hiển thị thông báo ĐĂNG KÝ Thành công hay Thất bại
                    Toast.makeText(com.example.quanlychitieu.RegisterActivity.this, msg, Toast.LENGTH_SHORT).show();
                    //Chuyển sang trang đăng nhập
                    Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                    startActivity(intent);
                    onBackPressed();



                }
                else {
                    Toast.makeText(RegisterActivity.this, "Kiểm tra lại mật khẩu xác nhận", Toast.LENGTH_LONG).show();
                }

            }
        });



    }

}
