package com.example.quanlychitieu;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);
        Button btn_register;
        btn_register = (Button)findViewById(R.id.btn_register);
        EditText us;
        EditText password;
        EditText confirm_pass;
        confirm_pass = (EditText)findViewById(R.id.confirm_pass);
        password = (EditText)findViewById(R.id.password) ;
        us = (EditText)findViewById(R.id.us);
        btn_register.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                String mk, xnmk;
                mk = password.getText().toString();
                xnmk = confirm_pass.getText().toString();
                if (mk.equals(xnmk)){
                    Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                    startActivity(intent);
                }
                else {
                    Toast.makeText(RegisterActivity.this, "Kiểm tra lại mật khẩu xác nhận", Toast.LENGTH_LONG).show();
                }

            }
        });



    }


}
