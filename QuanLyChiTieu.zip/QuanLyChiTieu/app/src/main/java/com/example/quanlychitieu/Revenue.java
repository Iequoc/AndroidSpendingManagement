package com.example.quanlychitieu;

 import androidx.appcompat.app.AlertDialog;
 import androidx.appcompat.app.AppCompatActivity;

 import android.app.Dialog;
 import android.content.ContentValues;
 import android.content.DialogInterface;
 import android.content.Intent;
 import android.database.Cursor;
 import android.database.sqlite.SQLiteDatabase;
 import android.os.Bundle;
 import android.util.Log;
 import android.view.View;
 import android.widget.ArrayAdapter;
 import android.widget.Button;
 import android.widget.EditText;
 import android.widget.ListView;
 import android.widget.Toast;

 import com.example.quanlychitieu.R;

 import java.util.ArrayList;

 public class  Revenue extends AppCompatActivity {
     Button btn_out;
     Button btn_addExpenses;
     Button btn_expenses;
     Button btn_statistical;

     ListView containerData;
     ArrayList<String> myData;
     ArrayAdapter<String> myAdapter;
     SQLiteDatabase myDatabase;
     @Override
     protected void onCreate(Bundle savedInstanceState) {
         super.onCreate(savedInstanceState);
         setContentView(R.layout.revenue);
         //Chuyển sang trang khoản chi
         btn_expenses = (Button)findViewById(R.id.btn_expenses);
         btn_expenses.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 Intent intent = new Intent(Revenue.this, MainActivity.class);
                 startActivity(intent);
             }
         });


         //Chuyển sang trang thống kê
         btn_statistical = (Button)findViewById(R.id.btn_statistical);
         btn_statistical.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 Intent intent = new Intent(Revenue.this, StatisticalActivity.class);
                 startActivity(intent);
             }
         });
         //Tạo ListView
         containerData = findViewById(R.id.containerData);
         myData = new ArrayList<>();
         myAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, myData);
         containerData.setAdapter(myAdapter);
         //Tạo (nếu chưa có) hoặc là mở CSDL
         myDatabase = openOrCreateDatabase("QuanLyChiTieu.db",MODE_PRIVATE, null);
         //Tạo table chứa dữ liệu
         try {
             String sql = "CREATE TABLE TB_THU(ID INTEGER PRIMARY KEY AUTOINCREMENT, TEN_KT TEXT, TIEN INTEGER )";
             myDatabase.execSQL(sql);
         }
         catch (Exception e)
         {
             Log.e("Error", "Bảng đã tồn tại");
         }


         btn_out = (Button)findViewById(R.id.btn_out);
         btn_addExpenses = (Button)findViewById(R.id.btn_addExpenses);

         //Thoát app
         btn_out.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 Intent intent = new Intent(Revenue.this, LoginActivity.class);
                 startActivity(intent);

             }
         });
         //Thêm khoản chi
         btn_addExpenses.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 Dialog add_expenses = new Dialog(com.example.quanlychitieu.Revenue.this);
                 add_expenses.setContentView(R.layout.add_revenue);
                 Button btn_confirmAdd = (Button)add_expenses.findViewById(R.id.btn_confirmAdd);
                 EditText name_Expenses = (EditText)add_expenses.findViewById(R.id.name_Expenses);
                 EditText money_Expenses = (EditText)add_expenses.findViewById(R.id.money_Expenses);
                 btn_confirmAdd.setOnClickListener(new View.OnClickListener() {
                     @Override
                     public void onClick(View view) {
                         String name = name_Expenses.getText().toString();
                         int money = Integer.parseInt(money_Expenses.getText().toString());
                         ContentValues myValues = new ContentValues();
                         myValues.put("TEN_KT", name);
                         myValues.put("TIEN", money);
                         String msg ="";
                         if (myDatabase.insert("TB_THU",null, myValues) == -1){
                             msg = "Thêm khoản thu THẤT BẠI!!!";
                         }
                         else {
                             msg = "THÀNH CÔNG Thêm khoản thu";
                         }
                         Toast.makeText(com.example.quanlychitieu.Revenue.this, msg, Toast.LENGTH_SHORT).show();
                         //Hiện thị toàn bộ dữ liệu
                         myData.clear();
                         Cursor c = myDatabase.query("TB_THU",null,null, null, null, null,null);
                         c.moveToNext();
                         String data = "";
                         while (c.isAfterLast() == false){
                             data = c.getString(0) + " | " + c.getString(1) + " | " + c.getString(2);
                             c.moveToNext();
                             myData.add(data);
                         }
                         c.close();
                         myAdapter.notifyDataSetChanged();


                     }
                 });
                 add_expenses.show();

             }
         });
         LoadData();


     }
     private void LoadData(){
         myData.clear();
         String sql = "SELECT * FROM TB_THU";
         Cursor c = myDatabase.rawQuery(sql, null);
         c.moveToFirst();
         String data = "";
         while (!c.isAfterLast()){
             data = c.getString(0) + " | " + c.getString(1) + " | " + c.getString(2);
             myData.add(data);
             c.moveToNext();
         }
         c.close();
         myAdapter.notifyDataSetChanged();

     }

 }