package com.example.quanlychitieu;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    Button btn_out;
    Button btn_addExpenses, btn_updateExpenses, btn_deleteExpenses;

    Button btn_revenue;
    Button btn_statistical;

    ListView containerData;
    ArrayList<String> myData;
    ArrayAdapter<String> myAdapter;
    SQLiteDatabase myDatabase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Chuyển sang trang khoản thu
        btn_revenue = (Button)findViewById(R.id.btn_revenue);
        btn_revenue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, Revenue.class);
                startActivity(intent);
                //Chuyển Activity bằng Intent cần "finsh()" để khi thoát app tất cả các Activity đã "start" trước đó sẽ đóng
                finish();
            }
        });
        //Chuyển sang trang thống kê
        btn_statistical = (Button)findViewById(R.id.btn_statistical);
        btn_statistical.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, StatisticalActivity.class);
                startActivity(intent);
                finish();
            }
        });
        //Tạo ListView
        containerData = findViewById(R.id.containerData);
        myData = new ArrayList<>();
        myAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, myData);
        containerData.setAdapter(myAdapter);
        //Tạo CSDL
        myDatabase = openOrCreateDatabase("QuanLyChiTieu.db",MODE_PRIVATE, null);
        //Tạo table chứa dữ liệu
        try {
            String sql = "CREATE TABLE TB_CHI(ID INTEGER PRIMARY KEY AUTOINCREMENT, TEN_KC TEXT, TIEN INTEGER )";
            myDatabase.execSQL(sql);
        }
        catch (Exception e)
        {
            Log.e("Error", "Bảng đã tồn tại");
        }


        btn_out = (Button)findViewById(R.id.btn_out);
        btn_addExpenses = (Button)findViewById(R.id.btn_addExpenses);

        //Thoát app
        btn_out.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();

            }
        });

        //Thêm khoản chi
        btn_addExpenses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog add_expenses = new Dialog(MainActivity.this);
                add_expenses.setContentView(R.layout.add_expenses);
                Button btn_confirmAdd = (Button)add_expenses.findViewById(R.id.btn_confirmAdd);
                EditText name_Expenses = (EditText)add_expenses.findViewById(R.id.name_Expenses);
                EditText money_Expenses = (EditText)add_expenses.findViewById(R.id.money_Expenses);
                money_Expenses.setInputType(InputType.TYPE_CLASS_NUMBER);
                btn_confirmAdd.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String name = name_Expenses.getText().toString();
                        String x = money_Expenses.getText().toString();
                        String msg ="";
                        if (name.equals("") || x.equals("")){
                            msg = "Tất cả trường không được phép trống. Vui lòng kiểm tra lại!";

                        } else {
                            int money = Integer.parseInt(money_Expenses.getText().toString());
                            ContentValues myValues = new ContentValues();
                            myValues.put("TEN_KC", name);
                            myValues.put("TIEN", money);
                            if (myDatabase.insert("TB_CHI",null, myValues) == -1){
                                msg = "Thêm khoản chi THẤT BẠI!!!";
                            }
                            else {
                                msg = "THÀNH CÔNG Thêm khoản chi";
                            }

                        }

                        Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
                        //Hiện thị toàn bộ dữ liệu
                        myData.clear();
                        Cursor c = myDatabase.query("TB_CHI",null,null, null, null, null,null);
                        c.moveToNext();
                        String data = "";
                        while (c.isAfterLast() == false){
                            data = c.getString(0) + " | " + c.getString(1) + " | " + c.getString(2);
                            c.moveToNext();
                            myData.add(data);
                        }
                        c.close();
                        myAdapter.notifyDataSetChanged();


                    }
                });
                add_expenses.show();

            }
        });
        //Biến thao tác thêm, xóa:
        btn_deleteExpenses = (Button)findViewById(R.id.btn_deleteExpenses);
        btn_updateExpenses = (Button)findViewById(R.id.btn_updateExpenses);

        //Thao tác xóa
        btn_deleteExpenses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog delete = new Dialog(com.example.quanlychitieu.MainActivity.this);
                delete.setContentView(R.layout.delete_item);
                //Các biến bên trong Dialog "Xóa"
                //lấy nút xóa trên giao diện
                Button btn_delete = (Button)delete.findViewById(R.id.btn_confirmAdd);
                //Lấy id được nhập từ giao diện (Id chính là số thứ tự được hiển thị)
                EditText name_Expenses = (EditText)delete.findViewById(R.id.name_Expenses);
                name_Expenses.setInputType(InputType.TYPE_CLASS_NUMBER);
                //Lấy tên của khoản chi hoặc khoản thu cần xóa (có thể lấy cũng được, không cũng được)
                EditText money_Expenses = (EditText)delete.findViewById(R.id.money_Expenses);
                //Bắt sự kiện click "Xóa"
                btn_delete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String id = name_Expenses.getText().toString().trim();
                        String name = money_Expenses.getText().toString().trim();
                        String tb = ""; //Chứa thông báo
                        //Xét điều kiện của người dùng nhập vào
                        if (id.equals("")|| name.equals("") ){
                            //Nếu người dùng không nhập gì sẽ đưa ra thông báo
                            tb = "Tất cả trường không được phép trống. Vui lòng kiểm tra lại!";
                        }
                        else {
                            //Xóa bản ghi nếu có tồn tại và trả về thông báo
                            int n = myDatabase.delete("TB_CHI", "ID = ?", new String[]{id});

                            if (n == 0){
                                tb = "Chưa tồn tại giá trị để xóa";
                            }
                            else {
                                tb = n + " đã xóa THÀNH CÔNG";
                                LoadData();
                            }
                        }
                        //Hiển thị thông báo
                        Toast.makeText(com.example.quanlychitieu.MainActivity.this, tb, Toast.LENGTH_SHORT).show();

                    }
                });
                delete.show();




            }
        });
        //Thao tác cập nhật
        btn_updateExpenses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog update = new Dialog(com.example.quanlychitieu.MainActivity.this);
                update.setContentView(R.layout.update);
                EditText id_Expenses = (EditText)update.findViewById(R.id.id_Expenses);
                id_Expenses.setInputType(InputType.TYPE_CLASS_NUMBER);
                EditText name_Expenses = (EditText)update.findViewById(R.id.name_Expenses);
                EditText money_Expenses = (EditText)update.findViewById(R.id.money_Expenses);
                money_Expenses.setInputType(InputType.TYPE_CLASS_NUMBER);
                Button btn_confirmAdd = (Button)update.findViewById(R.id.btn_confirmAdd);
                btn_confirmAdd.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String id = id_Expenses.getText().toString().trim();
                        String name = name_Expenses.getText().toString().trim();
                        String x = money_Expenses.getText().toString().trim();
                        String tb = "";
                        if (id.equals("")|| name.equals("") || x.equals("") ){
                            //Nếu người dùng không nhập gì sẽ đưa ra thông báo
                            tb = "Tất cả trường không được phép trống. Vui lòng kiểm tra lại!";
                        } else {
                            int money = Integer.parseInt(money_Expenses.getText().toString());
                            ContentValues myValues = new ContentValues();
                            myValues.put("TEN_KC", name);
                            myValues.put("TIEN", money);
                            int n = myDatabase.update("TB_CHI", myValues, "ID = ?", new String[]{id});
                            if (n == 0){
                                tb = "Không có bản ghi để cập nhật";
                            }
                            else {
                                tb = n + " bản ghi đã cập nhật thành công";
                                LoadData();
                            }


                        }
                        Toast.makeText(com.example.quanlychitieu.MainActivity.this, tb, Toast.LENGTH_SHORT).show();



                    }
                });
                update.show();




            }
        });

        //Hiện thị danh sách đã có
        LoadData();


    }
    private void LoadData(){
        myData.clear();
        String sql = "SELECT * FROM TB_CHI";
        Cursor c = myDatabase.rawQuery(sql, null);
        c.moveToFirst();
        String data = "";
        while (!c.isAfterLast()){
            data = c.getString(0) + " | " + c.getString(1) + " | " + c.getString(2);
            myData.add(data);
            c.moveToNext();
        }
        c.close();
        myAdapter.notifyDataSetChanged();
    }
    public void onBackPressed() {
        AlertDialog.Builder myDialog = new AlertDialog.Builder(MainActivity.this);
        myDialog.setTitle("Quản lý chi tiêu");
        myDialog.setMessage("Bạn có muốn thoát ứng dụng không?");
        myDialog.setIcon(R.drawable.app_logo);
        myDialog.setPositiveButton("Thoát", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
            }
        });

        myDialog.setNegativeButton("Không", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        myDialog.show();

    }
}